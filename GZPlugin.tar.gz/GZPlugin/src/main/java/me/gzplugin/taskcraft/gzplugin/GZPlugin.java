package me.gzplugin.taskcraft.gzplugin;

import org.bukkit.plugin.java.JavaPlugin;

public final class GZPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic

    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
    function checkPremium(player: player) :: boolean:
    delete file "plugins/LogowaniePremium/%{_player}%.yml"
    create file "plugins/LogowaniePremium/%{_player}%.yml"
    download from "https://api.mojang.com/users/profiles/minecraft/%{_player}%" to "plugins/LogowaniePremium/%{_player}%.yml"
    set {_content} to content of file "plugins/LogowaniePremium/%{_player}%.yml"
            if {_content} contains "id":
            return true
            else:
            return false

    on quit:
    delete file "plugins/LogowaniePremium/%player%.yml"
}
